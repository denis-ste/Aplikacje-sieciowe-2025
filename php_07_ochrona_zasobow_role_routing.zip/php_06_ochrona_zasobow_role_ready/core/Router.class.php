<?php

namespace core;

use Exception;

/**
 * Router (obiektowy routing) – profesjonalna wersja dispatchera.
 *
 * Zasada działania (bez zmian funkcjonalnych względem wcześniejszego control()):
 * action -> kontroler -> metoda -> widok
 *
 * - whitelist akcji: uruchamiane są tylko akcje zarejestrowane w routerze
 * - kontrola ról: per trasa (allowed roles), centralnie, przed wywołaniem kontrolera
 * - bezpieczny default: setDefaultRoute()
 */
class Router {

    /** @var string|null */
    public $action = null;

    /** @var array<string, Route> */
    public $routes = [];

    /** @var string|null */
    private $default = null;

    /** @var string */
    private $login = 'login';

    public function setAction($action): void {
        $this->action = ($action === null || $action === '') ? null : (string)$action;
    }

    public function getAction(): ?string {
        return $this->action;
    }

    /**
     * Dodaje trasę w formie jawnej.
     *
     * @param string $action
     * @param string|null $namespace np. 'app\\controllers' (lub null dla domyślnego)
     * @param string $controller np. 'HomeCtrl'
     * @param string $method np. 'process'
     * @param array|string|null $roles lista ról lub pojedyncza rola; null => public
     */
    public function addRouteEx(string $action, ?string $namespace, string $controller, string $method, $roles = null): void {
        $this->routes[$action] = new Route($namespace, $controller, $method, $roles);
    }

    /**
     * Dodaje trasę z konwencją nazwy metody: action_<action>.
     * Przykład: addRoute('login','LoginCtrl') -> wywoła LoginCtrl::action_login().
     */
    public function addRoute(string $action, string $controller, $roles = null): void {
        $this->routes[$action] = new Route(null, $controller, 'action_' . $action, $roles);
    }

    public function setDefaultRoute(string $route): void {
        $this->default = $route;
    }

    public function setLoginRoute(string $route): void {
        $this->login = $route;
    }

    private function hasAnyAllowedRole($roles): bool {
        if ($roles === null) return true; // public

        if (is_array($roles)) {
            foreach ($roles as $role) {
                if (inRole((string)$role)) return true;
            }
            return false;
        }

        return inRole((string)$roles);
    }

    private function runRoute(Route $r): void {
        // Role-check (centralnie)
        if (!$this->hasAnyAllowedRole($r->roles)) {
            // Zachowujemy dotychczasowe zachowanie control(): komunikat + forward do login.
            $return = $_SERVER['REQUEST_URI'] ?? buildActionUrl('home');
            getMessages()->addInfo('Zaloguj się, aby uzyskać dostęp do tej strony.');
            forwardTo($this->login, ['return' => $return]);
        }

        // Budowa FQCN kontrolera
        if (empty($r->namespace)) {
            $fqcn = 'app\\controllers\\' . $r->controller;
        } else {
            $fqcn = rtrim($r->namespace, '\\') . '\\' . $r->controller;
        }

        $ctrl = new $fqcn();
        if (method_exists($ctrl, $r->method)) {
            $method = $r->method;
            $ctrl->$method();
        } else {
            throw new Exception('Method "' . $r->method . '" does not exist in "' . $fqcn . '"');
        }
        exit;
    }

    /**
     * Rozwiązuje akcję i uruchamia kontroler.
     * - jeśli akcja nie istnieje, odpala default
     * - jeśli default nie istnieje -> wyjątek (powinno być skonfigurowane w ctrl.php)
     */
    public function go(): void {
        $action = $this->action;

        if ($action !== null && isset($this->routes[$action])) {
            $this->runRoute($this->routes[$action]);
        }

        if ($this->default !== null && isset($this->routes[$this->default])) {
            $this->runRoute($this->routes[$this->default]);
        }

        throw new Exception('Route for "' . (string)$action . '" is not defined');
    }
}
