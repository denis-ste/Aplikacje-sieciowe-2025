<?php

namespace core;

/**
 * Definicja pojedynczej trasy routingu.
 *
 * action -> (namespace, controller, method, roles)
 */
class Route {
    /** @var string|null */
    public $namespace = null;
    /** @var string */
    public $controller = '';
    /** @var string */
    public $method = '';
    /** @var array|string|null */
    public $roles = null;

    /**
     * @param string|null $namespace
     * @param string $controller
     * @param string $method
     * @param array|string|null $roles
     */
    public function __construct($namespace, $controller, $method, $roles = null) {
        $this->namespace  = $namespace;
        $this->controller = $controller;
        $this->method     = $method;
        $this->roles      = $roles;
    }
}
