<?php

namespace app\results;

/**
 * Model wyniku - Kalkulator zwykły
 */
class CalcResult {
    public $result;
    public $op_name;
}
