<?php

namespace app\results;

/**
 * Wynik kalkulatora kredytowego.
 * Zachowujemy nazwę pola 'rata' (zgodnie z istniejącym kontrolerem i widokiem).
 */
class KredytResult {
    public $rata; // miesięczna rata
}
