<?php
// Kompatybilnosc wsteczna prawdziwy controller przeniesiony do app/controllers/.
require_once __DIR__ . '/controllers/CalcCtrl.class.php';
