<?php
// Backward compatibility: stary punkt wejścia kontrolera.
// Od wersji "nowa struktura" logika dispatch jest w /ctrl.php.
require_once __DIR__ . '/../ctrl.php';
