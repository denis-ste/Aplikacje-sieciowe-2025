<?php
// Backward compatibility stub. Real controller moved to app/controllers/.
require_once __DIR__ . '/controllers/KartaCtrl.class.php';
