<?php

namespace app\forms;

/**
 * Formularz kalkulatora kredytowego.
 */
class KredytForm {
    public $kwota;
    public $lata;
    public $oprocentowanie;
}
