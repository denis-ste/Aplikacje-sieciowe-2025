<?php

namespace app\forms;

/**
 * Model danych formularza - Logowanie
 */
class LoginForm {
    public $login;
    public $pass;
    public $returnUrl;
}
