<?php

namespace app\forms;

/**
 * Model danych formularza - Kalkulator zwykły
 * (zgodne z konwencją: x, y, op)
 */
class CalcForm {
    public $x;
    public $y;
    public $op;
}
