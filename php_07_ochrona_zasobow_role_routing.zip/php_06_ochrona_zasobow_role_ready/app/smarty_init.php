<?php
// Od wersji "nowa struktura" inicjacja Smarty odbywa się w init.php.
require_once __DIR__ . '/../init.php';
