FUNKCJONALNOŚĆ APLIKACJI PRZY LOGOWANIU. KONTA LOGUJĄCE

pełen dostęp 	   - admin : admin
ograniczony dostęp - user : user