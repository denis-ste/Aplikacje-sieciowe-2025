<?php
/* Smarty version 5.4.2, created on 2026-01-11 23:09:26
  from 'file:panel.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641f96888400_95300952',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '042527854ce0032a08b0084ec35233229cd15cd0' => 
    array (
      0 => 'panel.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641f96888400_95300952 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_58217212469641f9687f2e6_16090865', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_58217212469641f9687f2e6_16090865 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
?>

  <div class="card wide">
    <h1><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Witaj w systemie kalkulatorów!' ?? null : $tmp);?>
</h1>
    <h2><?php echo (($tmp = $_smarty_tpl->getValue('page_subtitle') ?? null)===null||$tmp==='' ? 'Wybierz rodzaj kalkulatora:' ?? null : $tmp);?>
</h2>

    <div class="btn-col">
      <a class="btn btn-secondary btn-block" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=calc">Zwykły kalkulator</a>
      <a class="btn btn-primary btn-block" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=kredyt">Kalkulator kredytowy</a>
      <a class="btn btn-danger btn-block" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=karta">Karta chroniona</a>
    </div>
  </div>
<?php
}
}
/* {/block 'content'} */
}
