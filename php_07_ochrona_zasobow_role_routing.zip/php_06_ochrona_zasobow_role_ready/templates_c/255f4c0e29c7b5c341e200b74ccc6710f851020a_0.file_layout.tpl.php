<?php
/* Smarty version 5.4.2, created on 2026-01-11 22:44:56
  from 'file:layout.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_696419d82d6131_22385443',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '255f4c0e29c7b5c341e200b74ccc6710f851020a' => 
    array (
      0 => 'layout.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_696419d82d6131_22385443 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Aplikacja' ?? null : $tmp);?>
</title>
  <link rel="stylesheet" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/css/ui.css">
</head>
<body>
  <div class="topbar">
    <div class="brand">Dzień dobry</div>
    <div class="topbar-right">
      <?php if ($_smarty_tpl->getValue('is_logged')) {?>
        <a class="toplink" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=logout">Wyloguj</a>
      <?php }?>
    </div>
  </div>

  <div class="page">
    <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_554757481696419d82d4e61_99605887', 'content');
?>

  </div>
</body>
</html>
<?php }
/* {block 'app_top'} */
class Block_430445501696419d82d5323_78129104 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\app\\views';
}
}
/* {/block 'app_top'} */
/* {block 'app_content'} */
class Block_2122876844696419d82d59e4_85588912 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\app\\views';
}
}
/* {/block 'app_content'} */
/* {block 'content'} */
class Block_554757481696419d82d4e61_99605887 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\app\\views';
?>

            <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_430445501696419d82d5323_78129104', 'app_top', $this->tplIndex);
?>

      <div id="app_content">
        <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_2122876844696419d82d59e4_85588912', 'app_content', $this->tplIndex);
?>

      </div>
    <?php
}
}
/* {/block 'content'} */
}
