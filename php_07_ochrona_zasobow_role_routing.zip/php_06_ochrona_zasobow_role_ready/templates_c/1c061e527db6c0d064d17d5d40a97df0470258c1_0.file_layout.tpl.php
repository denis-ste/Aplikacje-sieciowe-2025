<?php
/* Smarty version 5.4.2, created on 2026-01-11 22:41:39
  from 'file:layout.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641913de12b8_84664625',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1c061e527db6c0d064d17d5d40a97df0470258c1' => 
    array (
      0 => 'layout.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641913de12b8_84664625 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\php_04_obiektowosc\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Aplikacja' ?? null : $tmp);?>
</title>
  <link rel="stylesheet" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/css/ui.css">
</head>
<body>
  <div class="topbar">
    <div class="brand">Dzień dobry</div>
    <div class="topbar-right">
      <?php if ($_smarty_tpl->getValue('is_logged')) {?>
        <a class="toplink" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=logout">Wyloguj</a>
      <?php }?>
    </div>
  </div>

  <div class="page">
    <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_154131111169641913ddfd87_64120003', 'content');
?>

  </div>
</body>
</html>
<?php }
/* {block 'app_top'} */
class Block_162326129069641913de0220_83060780 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\php_04_obiektowosc\\app\\views';
}
}
/* {/block 'app_top'} */
/* {block 'app_content'} */
class Block_20232057369641913de0b65_30821156 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\php_04_obiektowosc\\app\\views';
}
}
/* {/block 'app_content'} */
/* {block 'content'} */
class Block_154131111169641913ddfd87_64120003 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\php_04_obiektowosc\\app\\views';
?>

            <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_162326129069641913de0220_83060780', 'app_top', $this->tplIndex);
?>

      <div id="app_content">
        <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_20232057369641913de0b65_30821156', 'app_content', $this->tplIndex);
?>

      </div>
    <?php
}
}
/* {/block 'content'} */
}
