<?php
/* Smarty version 5.4.2, created on 2026-01-11 22:44:56
  from 'file:welcome.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_696419d81eb873_21884321',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6ab842fd2ea0e467476f801417ac01fae8a0c953' => 
    array (
      0 => 'welcome.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_696419d81eb873_21884321 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_849461811696419d81e3986_90349855', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_849461811696419d81e3986_90349855 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\app\\views';
?>

  <div class="card">
    <h1><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Welcome!' ?? null : $tmp);?>
</h1>
    <h2><?php echo (($tmp = $_smarty_tpl->getValue('page_subtitle') ?? null)===null||$tmp==='' ? 'Witaj w systemie kalkulatorów' ?? null : $tmp);?>
</h2>
    <div class="center">
      <a class="btn btn-primary" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=login">Zaloguj się</a>
    </div>
  </div>
<?php
}
}
/* {/block 'content'} */
}
