<?php
/* Smarty version 5.4.2, created on 2026-01-11 23:09:31
  from 'file:CalcView.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641f9b08c599_90998189',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '718870610591d9e30303803ad1a46b173d259ba7' => 
    array (
      0 => 'CalcView.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641f9b08c599_90998189 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_30170639869641f9b074476_27439585', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_30170639869641f9b074476_27439585 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
?>

  <div class="card wide">
    <h1>Zwykły kalkulator</h1>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=calc">
      <div class="form-row">
        <label>Liczba 1:</label>
        <input type="text" name="liczba1" value="<?php echo htmlspecialchars((string)(($tmp = $_smarty_tpl->getValue('form')->x ?? null)===null||$tmp==='' ? '' ?? null : $tmp), ENT_QUOTES, 'UTF-8', true);?>
">
      </div>

      <div class="form-row">
        <label>Liczba 2:</label>
        <input type="text" name="liczba2" value="<?php echo htmlspecialchars((string)(($tmp = $_smarty_tpl->getValue('form')->y ?? null)===null||$tmp==='' ? '' ?? null : $tmp), ENT_QUOTES, 'UTF-8', true);?>
">
      </div>

      <div class="form-row">
        <label>Operacja:</label>
        <select name="operacja">
          <option value="plus"  <?php if (((($tmp = $_smarty_tpl->getValue('form')->op ?? null)===null||$tmp==='' ? 'plus' ?? null : $tmp)) == 'plus') {?>selected<?php }?>>+</option>
          <option value="minus" <?php if (((($tmp = $_smarty_tpl->getValue('form')->op ?? null)===null||$tmp==='' ? 'plus' ?? null : $tmp)) == 'minus') {?>selected<?php }?>>-</option>
          <option value="times" <?php if (((($tmp = $_smarty_tpl->getValue('form')->op ?? null)===null||$tmp==='' ? 'plus' ?? null : $tmp)) == 'times') {?>selected<?php }?>>*</option>
          <option value="div"   <?php if (((($tmp = $_smarty_tpl->getValue('form')->op ?? null)===null||$tmp==='' ? 'plus' ?? null : $tmp)) == 'div') {?>selected<?php }?>>/</option>
        </select>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Oblicz</button>
      </div>
    </form>

    <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="msg msg-error">
        <ul>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getErrors(), 'm');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach0DoElse = false;
?>
            <li><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('m'), ENT_QUOTES, 'UTF-8', true);?>
</li>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </ul>
      </div>
    <?php }?>

    <?php if ($_smarty_tpl->getValue('msgs')->isInfo()) {?>
      <div class="msg msg-ok">
        <ul>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getInfos(), 'm');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach1DoElse = false;
?>
            <li><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('m'), ENT_QUOTES, 'UTF-8', true);?>
</li>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </ul>
      </div>
    <?php }?>

    <?php if ((null !== ($_smarty_tpl->getValue('res')->result ?? null)) && !$_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="result">
        Wynik: <?php echo $_smarty_tpl->getValue('res')->result;?>

      </div>
    <?php }?>

    <div class="backline">
      <a href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=home">Powrót</a>
    </div>
  </div>
<?php
}
}
/* {/block 'content'} */
}
