<?php
/* Smarty version 5.4.2, created on 2026-01-11 22:41:39
  from 'file:panel.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641913ccef86_86263363',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'de68778596018eb47b45753cc98769e57811fd4a' => 
    array (
      0 => 'panel.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641913ccef86_86263363 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\php_04_obiektowosc\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_29968420269641913cc6741_69311764', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_29968420269641913cc6741_69311764 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_obiektowosc_front_controller_strict_one_url_namespaces\\php_04_obiektowosc\\app\\views';
?>

  <div class="card wide">
    <h1><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Witaj w systemie kalkulatorów!' ?? null : $tmp);?>
</h1>
    <h2><?php echo (($tmp = $_smarty_tpl->getValue('page_subtitle') ?? null)===null||$tmp==='' ? 'Wybierz rodzaj kalkulatora:' ?? null : $tmp);?>
</h2>

    <div class="btn-col">
      <a class="btn btn-secondary btn-block" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=calc">Zwykły kalkulator</a>
      <a class="btn btn-primary btn-block" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=kredyt">Kalkulator kredytowy</a>
      <a class="btn btn-danger btn-block" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=karta">Karta chroniona</a>
    </div>
  </div>
<?php
}
}
/* {/block 'content'} */
}
