<?php
/* Smarty version 5.4.2, created on 2026-01-11 23:09:14
  from 'file:login.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641f8a7f7023_06542608',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b27dacd68d413f15af29567821f8cc1a13d37b9b' => 
    array (
      0 => 'login.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641f8a7f7023_06542608 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_50328723669641f8a7e2fa0_84404849', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_50328723669641f8a7e2fa0_84404849 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
?>

  <div class="card">
    <h1>Logowanie</h1>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=login<?php if ($_GET['return']) {?>&return=<?php echo rawurlencode((string)$_GET['return']);
}?>">
      <div class="form-row">
        <label>Login:</label>
        <input type="text" name="login" value="<?php echo htmlspecialchars((string)$_smarty_tpl->getValue('login'), ENT_QUOTES, 'UTF-8', true);?>
">
      </div>

      <div class="form-row">
        <label>Hasło:</label>
        <input type="password" name="pass" value="">
      </div>

      <div class="form-row">
        <button type="submit" class="btn btn-primary btn-block">Zaloguj</button>
      </div>
    </form>

    <?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('messages')) > 0) {?>
      <div class="msg msg-err">
        <ul>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('messages'), 'm');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach0DoElse = false;
?>
            <li><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('m'), ENT_QUOTES, 'UTF-8', true);?>
</li>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </ul>
      </div>
    <?php }?>
  </div>
<?php
}
}
/* {/block 'content'} */
}
