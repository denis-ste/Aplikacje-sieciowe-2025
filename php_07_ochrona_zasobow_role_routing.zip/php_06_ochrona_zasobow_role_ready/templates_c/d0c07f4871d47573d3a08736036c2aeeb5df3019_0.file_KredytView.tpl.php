<?php
/* Smarty version 5.4.2, created on 2026-01-11 23:09:29
  from 'file:KredytView.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641f9988a823_00963902',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd0c07f4871d47573d3a08736036c2aeeb5df3019' => 
    array (
      0 => 'KredytView.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641f9988a823_00963902 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_122373453469641f9986f648_78452119', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_122373453469641f9986f648_78452119 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
?>

  <div class="card wide">
    <h1>Kalkulator kredytowy</h1>

    <form method="post" action="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=kredyt">
      <div class="form-row">
        <label>Kwota kredytu:</label>
        <input type="text" name="kwota" value="<?php echo htmlspecialchars((string)(($tmp = $_smarty_tpl->getValue('form')->kwota ?? null)===null||$tmp==='' ? '' ?? null : $tmp), ENT_QUOTES, 'UTF-8', true);?>
">
      </div>

      <div class="form-row">
        <label>Okres (w latach):</label>
        <input type="text" name="lata" value="<?php echo htmlspecialchars((string)(($tmp = $_smarty_tpl->getValue('form')->lata ?? null)===null||$tmp==='' ? '' ?? null : $tmp), ENT_QUOTES, 'UTF-8', true);?>
">
      </div>

      <div class="form-row">
        <label>Oprocentowanie (% rocznie):</label>
        <input type="text" name="oprocentowanie" value="<?php echo htmlspecialchars((string)(($tmp = $_smarty_tpl->getValue('form')->oprocentowanie ?? null)===null||$tmp==='' ? '' ?? null : $tmp), ENT_QUOTES, 'UTF-8', true);?>
">
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Oblicz ratę</button>
      </div>
    </form>

    <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="msg msg-error">
        <ul>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getErrors(), 'm');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach0DoElse = false;
?>
            <li><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('m'), ENT_QUOTES, 'UTF-8', true);?>
</li>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </ul>
      </div>
    <?php }?>

    <?php if ($_smarty_tpl->getValue('msgs')->isInfo()) {?>
      <div class="msg msg-ok">
        <ul>
          <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getInfos(), 'm');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('m')->value) {
$foreach1DoElse = false;
?>
            <li><?php echo htmlspecialchars((string)$_smarty_tpl->getValue('m'), ENT_QUOTES, 'UTF-8', true);?>
</li>
          <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
        </ul>
      </div>
    <?php }?>

    <?php if ((null !== ($_smarty_tpl->getValue('res')->rata ?? null)) && !$_smarty_tpl->getValue('msgs')->isError()) {?>
      <div class="result">Miesięczna rata: <?php echo sprintf("%.2f",$_smarty_tpl->getValue('res')->rata);?>
 zł</div>
    <?php }?>

    <div class="backline">
      <a href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=home">Powrót</a>
    </div>
  </div>
<?php
}
}
/* {/block 'content'} */
}
