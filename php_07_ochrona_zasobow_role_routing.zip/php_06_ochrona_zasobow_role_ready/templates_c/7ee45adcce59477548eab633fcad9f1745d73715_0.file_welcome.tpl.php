<?php
/* Smarty version 5.4.2, created on 2026-01-11 23:09:12
  from 'file:welcome.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641f88b727d6_53883012',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ee45adcce59477548eab633fcad9f1745d73715' => 
    array (
      0 => 'welcome.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641f88b727d6_53883012 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_159817017369641f88b6b383_01709615', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "layout.tpl", $_smarty_current_dir);
}
/* {block 'content'} */
class Block_159817017369641f88b6b383_01709615 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
?>

  <div class="card">
    <h1><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Welcome!' ?? null : $tmp);?>
</h1>
    <h2><?php echo (($tmp = $_smarty_tpl->getValue('page_subtitle') ?? null)===null||$tmp==='' ? 'Witaj w systemie kalkulatorów' ?? null : $tmp);?>
</h2>
    <div class="center">
      <a class="btn btn-primary" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=login">Zaloguj się</a>
    </div>
  </div>
<?php
}
}
/* {/block 'content'} */
}
