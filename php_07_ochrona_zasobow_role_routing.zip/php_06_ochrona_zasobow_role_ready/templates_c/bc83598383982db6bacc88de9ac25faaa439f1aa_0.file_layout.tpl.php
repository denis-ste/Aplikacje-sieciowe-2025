<?php
/* Smarty version 5.4.2, created on 2026-01-11 23:09:12
  from 'file:layout.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69641f88c589d4_16869058',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc83598383982db6bacc88de9ac25faaa439f1aa' => 
    array (
      0 => 'layout.tpl',
      1 => 1768167635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69641f88c589d4_16869058 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo (($tmp = $_smarty_tpl->getValue('page_title') ?? null)===null||$tmp==='' ? 'Aplikacja' ?? null : $tmp);?>
</title>
  <link rel="stylesheet" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/css/ui.css">
</head>
<body>
  <div class="topbar">
    <div class="brand">Dzień dobry</div>
    <div class="topbar-right">
      <?php if ($_smarty_tpl->getValue('is_logged')) {?>
        <a class="toplink" href="<?php echo $_smarty_tpl->getValue('app_url');?>
/?action=logout">Wyloguj</a>
      <?php }?>
    </div>
  </div>

  <div class="page">
    <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_158595121769641f88c57858_67470913', 'content');
?>

  </div>
</body>
</html>
<?php }
/* {block 'app_top'} */
class Block_82726704669641f88c57cd8_99265627 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
}
}
/* {/block 'app_top'} */
/* {block 'app_content'} */
class Block_154432102269641f88c582c2_64996361 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
}
}
/* {/block 'app_content'} */
/* {block 'content'} */
class Block_158595121769641f88c57858_67470913 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\KATALOG_ZADANIA\\php_05_nowa_struktura\\app\\views';
?>

            <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_82726704669641f88c57cd8_99265627', 'app_top', $this->tplIndex);
?>

      <div id="app_content">
        <?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_154432102269641f88c582c2_64996361', 'app_content', $this->tplIndex);
?>

      </div>
    <?php
}
}
/* {/block 'content'} */
}
