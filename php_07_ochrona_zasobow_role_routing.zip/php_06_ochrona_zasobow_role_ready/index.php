<?php
require_once __DIR__ . '/init.php';
// forward do kontrolera głównego
include __DIR__ . '/ctrl.php';
