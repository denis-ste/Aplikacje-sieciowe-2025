<?php
require_once __DIR__ . '/init.php';

// Kontroler główny (front controller)
// ------------------------------------------------------------
// Wersja "routing" (jak we wzorcu php_07_routing):
// - bez switch/case
// - trasy rejestrowane w obiekcie core\Router
// - whitelist akcji + centralna kontrola dostępu (role-check)

// Akcja logowania na potrzeby helperów (np. LoginCtrl)
getConf()->login_action = 'login';

// Domyślna akcja zależna od sesji (bez zmian funkcjonalnych)
if ($action === null || $action === '') {
    $action = is_logged_in() ? 'home' : 'start';
}

// Kompatybilność: aliasy akcji
if ($action === 'credit') {
    $action = 'kredyt';
}

// Konfiguracja routera
$router = getRouter();
$router->setAction($action);
$router->setLoginRoute('login');
$router->setDefaultRoute(is_logged_in() ? 'home' : 'start');

// Role "zalogowane" (jak dotychczas)
$rolesLogged = ['user', 'admin', 'manager'];

// Rejestr tras (action -> controller -> method)
// Publiczne:
$router->addRouteEx('start',  'app\\controllers', 'StartCtrl', 'process');
$router->addRouteEx('login',  'app\\controllers', 'LoginCtrl', 'doLogin');

// Chronione:
$router->addRouteEx('logout', 'app\\controllers', 'LoginCtrl', 'doLogout', $rolesLogged);
$router->addRouteEx('home',   'app\\controllers', 'HomeCtrl',  'process',  $rolesLogged);
$router->addRouteEx('calc',   'app\\controllers', 'CalcCtrl',  'process',  $rolesLogged);
$router->addRouteEx('kredyt', 'app\\controllers', 'KredytCtrl','process',  $rolesLogged);
$router->addRouteEx('karta',  'app\\controllers', 'KartaCtrl', 'process',  $rolesLogged);

// Start
$router->go();
