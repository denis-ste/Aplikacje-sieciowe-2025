<?php
// Backward compatibility: Messages przeniesione do /core
require_once __DIR__ . '/../core/Messages.class.php';
